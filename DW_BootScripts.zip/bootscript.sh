#!/system/bin/sh
set -e

BROWSER_FLAG=/data/adb/.browser_hidden
LOGFILE=/data/local/tmp/bootscript.log

exec >>"$LOGFILE" 2>&1
echo "---- browser hide check at $(date) ----"

echo "Waiting for browser app to become available..."
while true; do
  if pm list packages | grep -q com.android.browser; then
    echo "Browser app detected. Disabling and hiding..."
    pm disable com.android.browser
    pm hide com.android.browser
    echo "Browser disabled and hidden successfully at $(date)" >> "$BROWSER_FLAG"
    break
  fi
  sleep 1
done